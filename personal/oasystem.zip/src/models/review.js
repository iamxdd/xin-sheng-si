import { create, remove, update,commit, query } from '../services/review';
import {listOfCalculate} from '../services/release';
import { parse } from 'qs'
import {message} from 'antd'
import {abc} from '../utils'
export default {

  namespace: 'review',
  state: {
    origin:[],
    list: [],
    loading: false,
    currentItem: {},
    modalVisible: false,
    modalType: 'create',
    pagination: {
      showSizeChanger: true,
      showQuickJumper: true,
      showTotal: total => `共 ${total} 条`,
      current: 1,
      total: null
    }
  },

  subscriptions: {
    setup ({ dispatch, history }) {
      history.listen(location => {
        if (location.pathname === '/review/list') {
          dispatch({
            type: 'query',
            payload: location.query
          })
        }
      })
    }
  },

  effects: {
    *query ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      
      const data = yield call(query, parse(payload));
      const copyList=data.review.concat()
     
      localStorage.setItem("copyList",JSON.stringify(copyList))
      yield put({
        type: 'querySuccess',
        payload: {
          list: data.review,
          origin:data.origin
        }
      })
    },
    *'delete' ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const data = yield call(remove, { id: payload });
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *create ({ payload }, { call, put }) {
      yield put({ type: 'hideModal' });
      yield put({ type: 'showLoading' });

      const data = yield call(create, payload);
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *update ({ payload }, { select, call, put }) {
      yield put({ type: 'showLoading' });

      const newReview = { ...payload.item};
     
      const items=newReview["cause"];
     
      //验证=》修改数值后必须要选择原因

      delete newReview.cause;
      let cause="";
      if(items!=undefined){
        for (var key of Object.keys(items)) {
            
            if(newReview[key]!=undefined){
              let content=items[key]["content"]
              if(items[key]["isChecked"]){
                content="数值修约:"+content
              }
              //如果数据无效，将数值置为-2
              let isValid=items[key]["isValid"]
              if(isValid==0){
                newReview[key]=-2
              }
              cause+="|"+key+","+content+","+isValid
            }
        }
        if(cause!=""){
          cause=cause.substring(1);
          newReview["cause"]=cause
        }
      }
    
      let len=Object.keys(newReview).length;

      if(len<=1){
        yield put({
          type: 'editDone',
          payload:{
            ...payload
          }
        });
        return
      }

      const data = yield call(update, newReview);
      if (!data.errcode) {
        yield put({ 
          type: 'reload',
          payload:{
            ...payload
          }
       });
      }else{

        yield put({
          type: 'editDone',
          payload:{
            ...payload
          }
        });

      }
    },
    *commit ({ payload }, { select,call, put }) {

      yield put({ type: 'showLoading' });
      const item = yield select(({ review }) => review.list[0])
      
      if(item==undefined){
        message.error("无数据上传")
        return
      }
      payload.timepoint=item.timepoint
      const data = yield call(commit, payload);
      if (!data.errcode) {
        yield put({ 
          type: 'reload', 
          payload:{
            ...payload
          } 
        });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *reload(action, { put, select }) {
      const page = yield select(({ review }) => review.pagination);
      
      yield put({ type: 'query', 
        payload: {
          page:page.current,
          timepoint:action.payload.timepoint
       } 
      });
    },
  },

  reducers: {

    showLoading (state) {
      return { ...state, loading: true }
    },
    hideLoading (state) {
      return { ...state, loading: false }
    },
    querySuccess (state, action) {
      const {list, origin,pagination} = action.payload
      const timestamp=new Date().getTime()
      return { ...state,
        list,
        origin,
        timestamp,
        loading: false,
        pagination: {
          ...state.pagination,
          ...pagination
        }}
    },
    showModal (state, action) {
      return { ...state, ...action.payload, modalVisible: true }
    },
    hideModal (state) {
      return { ...state, modalVisible: false }
    },

    onEdit (state,action) {
      let list=action.payload.data;
      list[action.payload.index].editable=true;
      return { ...state ,
        copyList:[],
        list:list
      }
    },
    editDone (state,action) {
      
      const copyList=JSON.parse(localStorage.getItem("copyList"))
      let list=action.payload.data;
      let index=action.payload.index;

      list[index].editable=false;
      list[index].status=action.payload.status;

      //重新计算审核后的最小值、最大值、平均值
      //const cleanList=list.slice(0,list.length-4);
      //const array=abc(cleanList)
      
      return { ...state ,
        copyList:copyList,
        list:list,
        loading: false
      }
    }
  }

}
