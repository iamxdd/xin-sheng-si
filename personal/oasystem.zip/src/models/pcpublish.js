import { stationQuery, query } from '../services/pcpublish';
import { parse } from 'qs'

export default {

  namespace: 'pcpublish',

  state: {
    list: [],
    daylist:[],
    loading: false,
    currentItem: {},
    modalVisible: false,
    modalType: 'create',
    pagination: {
      showSizeChanger: true,
      showQuickJumper: true,
      showTotal: total => `共 ${total} 条`,
      current: 1,
      total: null
    }
  },

  subscriptions: {
    setup ({ dispatch, history }) {
      history.listen(location => {
        /*pathname路由*/
        if (location.pathname === '/publishdata') {
          dispatch({
            type: 'query',
            payload: location.query
          });
          dispatch({
            type: 'stationQuery',
            payload: location.stationQuery
          });
        }
      })
    }
  },


  effects: {
    *query ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const data = yield call(query, parse(payload));
      const data2 = yield call(stationQuery, parse(payload));
      yield put({
        type: 'querySuccess',
        payload: {
          list: data.data,
          daylist:data2.data,
          pagination: {
            total: data.page.rows,
            current: data.page.current
          }
        }
      })
    },
   /* *stationQuery ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const data = yield call(stationQuery, parse(payload));
      yield put({
        type: 'querySuccess',
        payload: {
          list: data.data,
          pagination: {
            total: data.page.rows,
            current: data.page.current
          }
        }
      })
    },*/
  },

  reducers: {

    showLoading (state) {
      return { ...state, loading: true }
    },
    hideLoading (state) {
      return { ...state, loading: false }
    },
    querySuccess (state, action) {
      const {list,daylist, pagination} = action.payload;
      return { ...state,
        list,
        daylist,
        loading: false,
        pagination: {
          ...state.pagination,
          ...pagination
        }}
    },
    showModal (state, action) {
      return { ...state, ...action.payload, modalVisible: true }
    },
    hideModal (state) {
      return { ...state, modalVisible: false }
    }
  }

}
