import { create, remove, update, query,updateAllFlog } from '../services/release'
import { stationQuery } from '../services/station'
import { parse } from 'qs'

export default {

  namespace: 'release',

  state: {
    origin:[],
    list: [],
    stations:{data:[]},
    loading: false,
    currentItem: {},
    modalVisible: false,
    modalType: 'create',
    pagination: {
      showSizeChanger: true,
      showQuickJumper: true,
      showTotal: total => `共 ${total} 条`,
      current: 1,
      total: null
    }
  },

  subscriptions: {
    setup ({ dispatch, history }) {

      history.listen(location => {
        if (location.pathname === '/review/release') {
          dispatch({
            type: 'query',
            payload: location.query
          })
        }
      })
    }
  },

  effects: {
    *query ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const stations = yield call(stationQuery,{});
      if(payload.stationCode==undefined){
        payload.stationCode=stations.data[0].code
      }

      const data = yield call(query, parse(payload));
      
      yield put({
        type: 'querySuccess',
        payload: {
          list: data.review,
          origin:data.origin,
          stations:stations
        }
      })
    },
    *'delete' ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const data = yield call(remove, { id: payload });
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },

    *update ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });

      const data = yield call(update, {id:payload.id,flag:payload.flag});
      if (!data.errcode) {
        yield put({ 
          type: 'reload', 
          payload:{
            ...payload
          } 
         });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *reload(action, { put, select }) {
      const page = yield select(({ release }) => release.pagination);

      yield put({ type: 'query', 
        payload: {
          page:page.current,
          stationCode:action.payload.stationCode,
          timepoint:action.payload.timepoint
        }
       });
    },
    *updateAllflog ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const data = yield call(updateAllFlog, parse(payload));
      
      yield put({ type: 'reload' ,payload: {
          timepoint:payload.timepoint,
          stationCode:payload.stationCode
      }});
    },
  },

  reducers: {

    showLoading (state) {
      return { ...state, loading: true }
    },
    hideLoading (state) {
      return { ...state, loading: false }
    },
    querySuccess (state, action) {
      const {list,origin, stations} = action.payload;
      return { ...state,
        list,
        origin,
        loading: false,
        stations:stations
      }
    },
    showModal (state, action) {
      return { ...state, ...action.payload, modalVisible: true }
    },
    hideModal (state) {
      return { ...state, modalVisible: false }
    }
  }

}
