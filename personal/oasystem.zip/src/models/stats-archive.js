import { create, remove, update, query,findBgf } from '../services/stats'
import { parse } from 'qs'

export default {

  namespace: 'statsArchive',

  state: {
    list: [],
    list1:[],
    stations:[],
    loading: false,
    numbers:{so2:1,co:1,o3:1,no2:1,pm10:1,pm25:1},
    currentItem: {},
    modalVisible: false,
    modalType: 'create',
    pagination: {
      showSizeChanger: true,
      showQuickJumper: true,
      showTotal: total => `共 ${total} 条`,
      current: 1,
      total: null
    }
  },

  subscriptions: {
    setup ({ dispatch, history }) {

      history.listen(location => {
        
        if (location.pathname === '/stats/archive') {
          dispatch({
            type: 'queryStation'
          })
        }
      })
    }
  },

  effects: {
    *query ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      if (payload.dataType==undefined){
        payload.dataType =1
      }

      const data = yield call(findBgf, parse(payload));

      yield put({
        type: 'querySuccess',
        payload: {
          list: [],
          list1:data,
          numbers:payload.numbers
        }
      })
    },
    *'delete' ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const data = yield call(remove, { id: payload });
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *create ({ payload }, { call, put }) {
      yield put({ type: 'hideModal' });
      yield put({ type: 'showLoading' });

      const data = yield call(create, payload);
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *update ({ payload }, { select, call, put }) {
      yield put({ type: 'hideModal' });
      yield put({ type: 'showLoading' });
      const id = yield select(({ station }) => station.currentItem.id);

      const newStation = { ...payload, id };
      const data = yield call(update, newStation);
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *reload(action, { put, select }) {
      const page = yield select(({ station }) => station.pagination);
      yield put({ type: 'query', payload: {
          page:page.current
       } });
    },
    *queryStation ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
     
      const stations = yield call(query,{});
      
      yield put({
        type: 'queryStationSuccess',
        payload: {
          stations:stations.data
        }
      })
    },

  },

  reducers: {

    showLoading (state) {
      return { ...state, loading: true }
    },
    hideLoading (state) {
      return { ...state, loading: false }
    },
    querySuccess (state, action) {
      const {list,list1,numbers} = action.payload;
      return { ...state,
        list,
        list1,
        loading: false,
        numbers:numbers
      }
    },
    queryStationSuccess (state, action) {
      const {stations} = action.payload;
      return { ...state,
        loading: false,
        stations:stations
      }
    },

    dataTypeChange (state,action) {
      return { ...state,  ...action.payload }
    }
  }

}
