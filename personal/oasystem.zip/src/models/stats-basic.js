import { hourDataAQI,create, remove, update, query } from '../services/stats'

import { parse } from 'qs'

export default {

  namespace: 'statsBasic',

  state: {
    list: [],
    list1:[],
    stations:{data:[]},
    activeMenu:'hour',
    timestamp:1,
    loading: false,
    currentItem: {},
    modalVisible: false,
    modalType: 'create',
    pagination: {
      showSizeChanger: true,
      showQuickJumper: true,
      showTotal: total => `共 ${total} 条`,
      current: 1,
      total: null
    }
  },

  subscriptions: {
    setup ({ dispatch, history }) {
      history.listen(location => {
        if (location.pathname === '/stats/basic') {
          dispatch({
            type: 'query',
            payload: {
              ...location.query,
             /* type:'hour'*/
            }
          })
        }
      })
    }
  },

  effects: {
    *query ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const stations = yield call(query,{});
     
      if(payload.stationCode==undefined){
        payload.stationCode="4"
      }
      if(payload.type==undefined){
        payload.type="hour"
      }
      const data = yield call(hourDataAQI, parse(payload));

      yield put({
        type: 'querySuccess',
        payload: {
          list: data,
          stations:stations,
          activeMenu:payload.type,
          timestamp:new Date().getTime(),
          pagination: {

          }
        }
      })
    },
    *'delete' ({ payload }, { call, put }) {
      yield put({ type: 'showLoading' });
      const data = yield call(remove, { id: payload });
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *create ({ payload }, { call, put }) {
      yield put({ type: 'hideModal' });
      yield put({ type: 'showLoading' });
      const data = yield call(create, payload);
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *update ({ payload }, { select, call, put }) {
      yield put({ type: 'hideModal' });
      yield put({ type: 'showLoading' });
      const id = yield select(({ station }) => station.currentItem.id);

      const newStation = { ...payload, id };
      const data = yield call(update, newStation);
      if (!data.errcode) {
        yield put({ type: 'reload' });
      }else{
        yield put({ type: 'hideLoading' })
      }
    },
    *reload(action, { put, select }) {
      const page = yield select(({ station }) => station.pagination);
      yield put({ type: 'query', payload: {
          page:page.current
       } });
    },
    *navigator(action, { put, select }) {

      yield put({ type: 'menuChange', payload: {
          ...action.payload
       } });
    },
  },

  reducers: {

    showLoading (state) {
      return { ...state, loading: true }
    },
    hideLoading (state) {
      return { ...state, loading: false }
    },
    querySuccess (state, action) {
      const {list,pagination,stations,activeMenu,timestamp} = action.payload;
    
      return { ...state,
        list,
        loading: false,
        stations:stations,
        activeMenu:activeMenu,
        timestamp:timestamp,
        pagination: {
          ...state.pagination,
          ...pagination
        }}
    },
    menuChange (state, action) {
      return { ...state, ...action.payload}
    }
  }

}
