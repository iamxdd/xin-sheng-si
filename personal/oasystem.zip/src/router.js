import React from 'react'
import {Router} from 'dva/router'
import App from './routes/app'

const cached = {};

function registerModel(app, model) {
  if (!cached[model.namespace]) {
    app.model(model);
    cached[model.namespace] = 1;
  }
}

function RouterConfig({history, app}) {
  const routes = [
    /*
    {
      path: '/login',
      name: 'login',
      getComponent(nextState, cb) {
        require.ensure([], (require) => {
          registerModel(app, require('./models/common'));
          cb(null, require('./routes/login'));
        });
      },
    },*/
    {
      path: '/',
      component: App,
      getIndexRoute (nextState, cb) {
        require.ensure([], require => {
          //registerModel(app,require('./models/app'))
          cb(null, {component: require('./routes/dashboard')})
        })
      },

      childRoutes: [
        {
          path: 'dashboard',
          name: 'dashboard',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              cb(null, require('./routes/dashboard'))
            })
          }
        },{
          path: 'publishdata',
          name: 'pcpublish_table',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              registerModel(app, require('./models/pcpublish'));
              cb(null, require('./routes/pcpublish'))
            })
          }
        },{
          path: 'system/role',
          name: 'system-role',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              registerModel(app, require('./models/role'));
              cb(null, require('./routes/role'))
            })
          }
        },{
          path: 'system/module',
          name: 'system-module',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              registerModel(app, require('./models/module'));
              cb(null, require('./routes/module'))
            })
          }
        },{
          path: 'system/manager',
          name: 'system-manager',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              registerModel(app, require('./models/manager'));
              cb(null, require('./routes/manager'))
            })
          }
        },{
          path: 'review/list',
          name: 'review_list',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              registerModel(app, require('./models/review'));
              cb(null, require('./routes/review'))
            })
          }
        },{
          path: 'review/release',
          name: 'review_release',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              registerModel(app, require('./models/release'));
              cb(null, require('./routes/release'))
            })
          }
        },{
          path: 'stats/basic',
          name: 'stats-basic',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              registerModel(app, require('./models/stats-basic'));
              cb(null, require('./routes/stats-basic'))
            })
          }
        },{
          path: 'stats/archive',
          name: 'stats-archive',
          getComponent (nextState, cb) {
            require.ensure([], require => {
              registerModel(app, require('./models/stats-archive'));
              cb(null, require('./routes/stats-archive'))
            })
          }
        }
      ]

    }
  ]

  return <Router history={history} routes={routes} />
}

export default RouterConfig;
