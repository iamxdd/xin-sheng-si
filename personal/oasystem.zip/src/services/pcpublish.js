import { request } from '../utils'

export async function stationQuery (params) {
  return request('/hourPublish/day', {
    method: 'get',
    data: params
  })
}

export async function query (params) {
  return request('/hourPublish/hour', {
    method: 'get',
    data: params
  })
}


