import { request } from '../utils'

export async function hourDataAQI (params) {
  return request('/review/findAQI', {
    method: 'get',
    data: params
  })
}

export async function query (params) {
  return request('/station/list', {
    method: 'get',
    data: params
  })
}

export async function create (params) {
  return request('/station/store', {
    method: 'post',
    data: params
  })
}

export async function remove (params) {
  return request('/station/remove', {
    method: 'post',
    data: params
  })
}

export async function update (params) {
  return request('/station/update', {
    method: 'post',
    data: params
  })
}

export async function findBgf (params) {
  return request('/bgfData/findBgf', {
    method: 'get',
    data: params
  })
}
