import { request } from '../utils'

export async function login (params) {
    return request({
      url:"manager/login",
      method: 'post',
      data: params,
    })
}

export async function logout (params) {
  return request({
    url:"manager/logout",
    method: 'post',
    data: params,
  })
}

export async function userInfo (params) {
  return request({
    url:"manager/info",
    method: 'post',
    data: params,
  })
}
