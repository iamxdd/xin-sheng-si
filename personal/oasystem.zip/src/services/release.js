import { request } from '../utils'

export async function query (params) {
  return request('/release/list', {
    method: 'get',
    data: params
  })
}

export async function create (params) {
  return request('/review/store', {
    method: 'post',
    data: params
  })
}

export async function remove (params) {
  return request('/review/remove', {
    method: 'post',
    data: params
  })
}

export async function update (params) {
  return request('/release/update', {
    method: 'post',
    data: params
  })
}

export async function commit (params) {
  return request('/review/commit', {
    method: 'post',
    data: params
  })
}

export async function listOfCalculate (params) {
  return request('/review/listOfCalculate', {
    method: 'post',
    data: params
  })
}

export async function updateAllFlog (params) {
  return request('/release/updateAllFlog', {
    method: 'post',
    data: params
  })
}

