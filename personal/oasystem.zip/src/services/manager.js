import { request } from '../utils'

export async function managerquery (params) {
  return request( {
    url:'/manager/list',
    method: 'post',
    data: params
  })
}

export async function managercreate (params) {
  return request( {
    url:'/manager/add',
    method: 'post',
    data: params
  })
}

export async function managerupdate (params) {
  return request( {
    url:'/manager/update',
    method: 'post',
    data: params
  })
}


export async function managerremove (params) {
  return request( {
    url:'/manager/remove',
    method: 'post',
    data: params
  })
}

export async function updpwd (params) {
  return request( {
    url:'/manager/updpwd',
    method: 'post',
    data: params
  })
}

export async function permissions (params) {
  return request( {
    url:'/manager/permissions',
    method: 'post',
    data: params
  })
}

export async function removepermissions (params) {
  return request( {
    url:'/manager/remove_permissions',
    method: 'post',
    data: params
  })
}

export async function updatepermissions (params) {
  return request( {
    url:'/manager/update_permissions',
    method: 'post',
    data: params
  })
}

