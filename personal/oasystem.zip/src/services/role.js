import { request } from '../utils'
export async function query (params) {
  return request({
    url:'/role/list', 
    method: 'post',
    data: params
  })
}

export async function create (params) {
  return request({
    url:'role/add',
    method: 'post',
    data: params
  })
}

export async function remove (params) {
  return request({
    url:'/role/remove',
    method: 'post',
    data: params
  })
}

export async function update (params) {
  return request( {
    url:'/role/update',
    method: 'post',
    data: params
  })
}


export async function permissions (params) {
  return request( {
    url:'/role/permissions',
    method: 'post',
    data: params
  })
}


export async function removepermissions (params) {
  return request( {
    url:'/role/remove_permissions',
    method: 'post',
    data: params
  })
}

export async function updatepermissions (params) {
  return request( {
    url:'/role/update_permissions',
    method: 'post',
    data: params
  })
}
