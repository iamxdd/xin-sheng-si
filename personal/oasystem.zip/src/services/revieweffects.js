/**
 * Created by Administrator on 2017/3/1 0001.
 */
import {request} from '../utils';

export async function query(params) {
     return request("/review/dayAQI",{
          method:'get',
          data:params
     })
}
