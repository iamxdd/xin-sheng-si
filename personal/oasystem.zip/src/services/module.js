import { request } from '../utils'


//菜单集合
export  async function menulist(params) {
    return request({
      url:'menu/list',
      method:'post',
      data:params
    })
}

//菜单添加
export  async function menuadd(params) {
  return request({
    url:'menu/add',
    method:'post',
    data:params
  })
}

//菜单修改
export  async function menuupdate(params) {
  return request({
    url:'menu/update',
    method:'post',
    data:params
  })
}

//移除菜单
export  async function menuremove(params) {
  return request({
    url:'menu/remove',
    method:'post',
    data:params
  })
}