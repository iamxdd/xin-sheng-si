import { request } from '../utils'

export async function query (params) {
  return request('/review/list', {
    method: 'get',
    data: params
  })
}

export async function create (params) {
  return request('/review/store', {
    method: 'post',
    data: params
  })
}

export async function remove (params) {
  return request('/review/remove', {
    method: 'post',
    data: params
  })
}

export async function update (params) {
  return request('/review/update', {
    method: 'post',
    data: params
  })
}

export async function commit (params) {
  return request('/review/commitBatch', {
    method: 'post',
    data: params
  })
}
