module.exports = {
  // host:'http://127.0.0.1:8080',
  host:'http://182.135.64.132:100/airquality',
  /*  baseURL: 'http://localhost:8000/api/v1',*/
  /*  baseURL: 'http://10.190.1.3:9090/',*/
  /*baseURL: 'http://10.190.1.3:8080/',*/
  baseURL: 'http://192.168.199.180:20015/auth_backend',
  name: 'Admin',
  prefix: 'Admin',
  footerText: '版权所有 © 2017',
  logoSrc: 'https://www.lgstatic.com/thumbnail_300x300/image1/M00/2B/29/CgYXBlVuufuAZ_rbAAB_uRdY7-I061.png',
  logoText: '成都市府南河信息综合管理平台',
  gas:{
    "ICO":"一氧化碳(CO)",
    "INO2":"二氧化氮(NO2)",
    "IPM25":"细颗粒物(PM2.5)",
    "IPM10":"颗粒物(PM10)",
    "IO3":"臭氧(O3)",
    "ISO2":"二氧化硫(SO2)",
  },
  needLogin: true
}
