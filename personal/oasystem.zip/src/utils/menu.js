module.exports = [
  {
    key: 'dashboard',
    name: '首页',
    icon: 'laptop'
  },{
    key: 'system',
    name: '系统管理',
    icon: 'camera-o',
    clickable: false,
    child: [
      {
        key: 'role',
        action:'role_list',
        name: '角色管理'
      },
      {
        key: 'module',
        action:'module_list',
        name: '权限列表'
      },
      {
        key: 'manager',
        action:'manager_list',
        name: '系统用户'
      }
    ]
  }
];
