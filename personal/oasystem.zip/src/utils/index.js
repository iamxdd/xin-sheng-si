import config from './config'
import menu from './menu'
import menu2 from './menu2'
import request from './request'
import math from './math'
import classnames from 'classnames'
import {color} from './theme'

// 连字符转驼峰
String.prototype.hyphenToHump = function () {
  return this.replace(/-(\w)/g, function () {
    return arguments[1].toUpperCase()
  })
};

// 驼峰转连字符
String.prototype.humpToHyphen = function () {
  return this.replace(/([A-Z])/g, '-$1').toLowerCase()
};


// 日期格式化
Date.prototype.format = function (format) {
  var o = {
    'M+': this.getMonth() + 1,
    'd+': this.getDate(),
    'h+': this.getHours(),
    'H+': this.getHours(),
    'm+': this.getMinutes(),
    's+': this.getSeconds(),
    'q+': Math.floor((this.getMonth() + 3) / 3),
    'S': this.getMilliseconds()
  };
  if (/(y+)/.test(format)) { format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length)) }
  for (var k in o) {
    if (new RegExp('(' + k + ')').test(format)) {
      format = format.replace(RegExp.$1, RegExp.$1.length === 1
        ? o[k]
        : ('00' + o[k]).substr(('' + o[k]).length))
    }
  }
  return format
};

function abc(list){
    
    let len=list.length
    let sum=[0,0,0,0,0,0]
    let count=[0,0,0,0,0,0]
    let max={
      'co':-2,
      'no2':-2,
      'so2':-2,
      'o3':-2,
      'pm10':-2,
      'pm25':-2
    }
    let min={
      'co':-2,
      'no2':-2,
      'so2':-2,
      'o3':-2,
      'pm10':-2,
      'pm25':-2
    }
    for(let i=0;i<len;i++){
        let m=list[i]
        for(let key in m){
          sum[key]+=m[key]
          if(m[key]>0){
            count[key]++
          }
          if(m[key]>max[key]){
            max[key]=m[key]
          }
          if(i==0){
            min[key]=m[key]
          }else{
            if(m[key]<min[key]){
              min[key]=m[key]
            }
          }
          
        }
     
        
    }
    //计算平均值
    let avg={
      'co':-2,
      'no2':-2,
      'so2':-2,
      'o3':-2,
      'pm10':-2,
      'pm25':-2
    }
    for(let i=0;i<avg.length;i++){
      if(count[i]!=0){
        avg[i]=(sum[i]/count[i]).toFixed(2)
      }
    }
    return [max,min,avg]

}

module.exports = {
  config,
  menu,
  menu2,
  request,
  math,
  color,
  classnames,
  abc
};
