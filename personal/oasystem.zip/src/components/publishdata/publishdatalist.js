/**
 * Created by Administrator on 2017/2/28 0028.
 */
import React,{PropTypes} from 'react';
import styles from './publishdatalist.less';

export default class publishdatalist extends React.Component{
    constructor(props){
      super(props)
    }
    render(){
      return(
        <div id="wrapper" className={styles.container}>
               <div id="header" className={styles.header}>
                   <h2>内江市空气质量监测系统</h2>
               </div>
               <div id="main" className={styles.main}>
                     <div id="main-right" className={styles.mainright}>
                          <div id="main-right-Bottom-right">
                                <div></div>
                                <div className={styles.tablewrapper}>
                                       <div>
                                           <table className={styles.tableheader}>
                                              <tbody>
                                                    <tr>
                                                      <th >站点</th>
                                                      <th >SO<span className="tiny">2</span></th>
                                                      <th >NO<span className="tiny">2</span></th>
                                                      <th >PM<span className="tiny">10</span></th>
                                                      <th >PM<span className="tiny">2.5</span></th>
                                                      <th >CO</th>
                                                      <th >O<span className="tiny">3</span></th>
                                                      <th >AQI</th>
                                                      <th >首要污染物</th>
                                                    </tr>
                                              </tbody>
                                           </table>
                                       </div>
                                       <div className={styles.tabledata}>
                                              <div id="table-content"></div>
                                       </div>
                                       <div className={styles.tablebottom}>单位：SO2、NO2、PM10、PM2.5、O3为μg/m3，CO为mg/m3</div>

                                </div>
                          </div>
                     </div>
               </div>


        </div>
      )
    }
}
