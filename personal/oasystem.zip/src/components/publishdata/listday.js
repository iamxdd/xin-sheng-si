import React from 'react'
import {Table, Dropdown, Button, Menu, Icon, Modal} from 'antd'
import {TweenOneGroup} from 'rc-tween-one'
import styles from './list.less'
const confirm = Modal.confirm;

class list extends React.Component {
  constructor (props) {
    super(props);
    
  }


  render () {
    const {loading, dataSorce2, pagination, onPageChange} = this.props;

    const columns = [
     {
        title: '站点',
        dataIndex: 'stationName',
        key: 'stationName'
      },{
        title: 'SO2',
        dataIndex: 'so2',
        key: 'so2',
        render: (text, record, index) => {
          return (<span>{parseInt(text)}</span>)
        }
      },{
        title: 'NO2',
        dataIndex: 'no2',
        key: 'no2',
        render: (text, record, index) => {
          return (<span>{parseInt(text)}</span>)
        }
      }, {
        title: 'CO',
        dataIndex: 'co',
        key: 'co',
        render: (text, record, index) => {
          return (<span>{text}</span>)
        }
      }, {
        title: 'O3',
        dataIndex: 'o3',
        key: 'o3',
        render: (text, record, index) => {
          return (<span>{parseInt(text)}</span>)
        }
      }, {
        title: 'PM10',
        dataIndex: 'pm10',
        key: 'pm10',
        render: (text, record, index) => {
          return (<span>{parseInt(text)}</span>)
        }
      },{
        title: 'PM2.5',
        dataIndex: 'pm25',
        key: 'pm25',
        render: (text, record, index) => {
          return (<span>{parseInt(text)}</span>)
        }
      },{
        title: 'AQI',
        dataIndex: 'aqi',
        key: 'aqi',
        render: (text, record, index) => {
          return (<span>{parseInt(text)}</span>)
        }
      }
    ];
    const self = this;
    const timestamp = Date.parse(new Date())
    //24小时前
    const n=timestamp-60*60*24*1000
    const t=new Date(n).format("yyyy-MM-dd")
    return <div>
              <h3>空气监测--日报</h3>
              <br/>
              <p>监测时间：({t})</p>
              <br/>
              <Table bordered columns={columns} dataSource={dataSorce2} loading={loading} pagination={false} simple rowKey={record => record.id} />
           </div>
  }
}

export default list
