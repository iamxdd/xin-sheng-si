import React from 'react'
import {Table, Dropdown, Button, Menu, Icon, Modal} from 'antd'
import {TweenOneGroup} from 'rc-tween-one'
import styles from './list.less'
require('../../utils')

const confirm = Modal.confirm;

class list extends React.Component {
  constructor (props) {
    super(props);
  }
  renderColumns(text){
    if(text<0){
      return '—'
    }
    return text
  }
  render () {
    const {loading, dataSource, pagination, onPageChange} = this.props;
    const columns = [
      {
        title: '站点',
        dataIndex: 'stationName',
        key: 'stationName'
      },{
        title: 'SO2',
        dataIndex: 'so2',
        key: 'so2',
        render: (text, record, index) => this.renderColumns(text)
      },{
        title: 'NO2',
        dataIndex: 'no2',
        key: 'no2',
        render: (text, record, index) => this.renderColumns(text)
      }, {
        title: 'CO',
        dataIndex: 'co',
        key: 'co',
        render: (text, record, index) => this.renderColumns(text)
      }, {
        title: 'O3',
        dataIndex: 'o3',
        key: 'o3',
        render: (text, record, index) => this.renderColumns(text)
      }, {
        title: 'PM10',
        dataIndex: 'pm10',
        key: 'pm10',
        render: (text, record, index) => this.renderColumns(text)
      },{
        title: 'PM2.5',
        dataIndex: 'pm25',
        key: 'pm25',
        render: (text, record, index) => this.renderColumns(text)
      },{
        title: 'AQI',
        dataIndex: 'aqi',
        key: 'aqi',
        render: (text, record, index) => this.renderColumns(text)
      }
    ];
    const self = this;
    const timestamp = Date.parse(new Date())
    //1小时前
    const n1=timestamp-60*60*1*1000
    const n2=timestamp//-60*60*1*1000
    const t1=new Date(n1).format("yyyy-MM-dd HH")+"时"
    const t2=new Date(n2).format("yyyy-MM-dd HH")+"时"
    return <div>
                <h3>空气监测-实时报</h3>
                <br/>
                <p>监测时间：({t1}-{t2})</p>
                <br/>
                <Table bordered columns={columns} dataSource={dataSource} loading={loading} pagination={false} simple rowKey={record => record.id} />
           </div>
  }
}

export default list
