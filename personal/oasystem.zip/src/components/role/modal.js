import React, { PropTypes } from 'react'
import { Form, Input,Select, InputNumber, Radio, Modal } from 'antd'
const FormItem = Form.Item

const formItemLayout = {
  labelCol: {
    span: 6
  },
  wrapperCol: {
    span: 14
  }
}

const modal = ({
  visible,
  type,
  permissions,
  item = {},
  onOk,
  onCancel,
  form: {
    getFieldDecorator,
    validateFields,
    getFieldsValue
  }
}) => {
  function handleOk () {
    validateFields((errors) => {
      if (errors) {
        return
      }
      const data = {
        ...getFieldsValue(),
        key: item.key
      }
      onOk(data)
    })
  }

  const modalOpts = {
    title: `${type === 'create' ? '新建角色' : '修改角色'}`,
    visible,
    maskClosable:false,
    onOk: handleOk,
    onCancel,
    wrapClassName: 'vertical-center-modal'
  }
  const children = []
  const modules=[]
  const permissionsLength=permissions.length

  for (let i = 0; i < permissionsLength; i++) {
    const obj=permissions[i]
    children.push(<Select.Option key={obj.id}>{obj.name}</Select.Option>);
  }
  if(item.modules!=undefined){
      const modulesLength=item.modules.length
      for (let i = 0; i < modulesLength; i++) {
        const obj=item.modules[i]
        modules.push(String(obj.id));
      }
  }
  
  function handleChange(value) {
    
  }
  return (
    <Modal {...modalOpts}>
      <Form horizontal>
        
        <FormItem label='角色名称：' hasFeedback {...formItemLayout}>
          {getFieldDecorator('name', {
            initialValue: item.name,
            rules: [
              {
                required: true,
                message: '角色名称未填写'
              }
            ]
          })(<Input />)}
        </FormItem>
        <FormItem label='权限列表：' hasFeedback {...formItemLayout}>
          {getFieldDecorator('permissions', {
            initialValue: modules
            //initialValue: ["7","8"]
          })(
            <Select
              multiple
              style={{ width: '100%' }}
              placeholder="请选择权限"
              onChange={handleChange}
            >
              {children}
            </Select>
          )}
        </FormItem>
        <FormItem label='角色描述：' hasFeedback {...formItemLayout}>
          {getFieldDecorator('description', {
            initialValue: item.description,
            rules: [
              {
                required: false,
                message: '角色描述未填写'
              }
            ]
          })(<Input type="textarea" rows={4}/>)}
        </FormItem>
      </Form>
    </Modal>
  )
}

modal.propTypes = {
  visible: PropTypes.any,
  form: PropTypes.object,
  item: PropTypes.object,
  onOk: PropTypes.func,
  onCancel: PropTypes.func
}

export default Form.create()(modal)
