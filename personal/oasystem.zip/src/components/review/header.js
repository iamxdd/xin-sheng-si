import React, { PropTypes } from 'react'
import { Form, Button, Row, Col,DatePicker } from 'antd'
import moment from 'moment'
import SearchGroup from '../ui/search'

const search = ({
  field,
  timepoint,
  onSearch,
  onAdd,
  form: {
    getFieldDecorator,
    validateFields,
    getFieldsValue
  }
}) => {
  const dateFormatString = 'YYYY-MM-DD';
  const defaultDate=timepoint==undefined?dateFormat(-1):timepoint;
  
  function dateFormat(count){
    var dd = new Date(); 
    dd.setDate(dd.getDate()+count);//获取count天后的日期 
    var y = dd.getFullYear(); 
    var m = dd.getMonth()+1;//获取当前月份的日期 
    var d = dd.getDate(); 
    return y+"/"+m+"/"+d; 
  }
  function disabledDate(current) {
    // can not select days after today and today

    return current && current.valueOf() > Date.now();
  }
  function onChange(date, dateString){
      onSearch({timepoint:dateString})
  }
  return (
    <Row gutter={24}>
      <Col lg={8} md={12} sm={16} xs={24} style={{marginBottom: 16}}>
        <DatePicker allowClear={false} disabledDate={disabledDate} defaultValue={moment(defaultDate, dateFormatString)} onChange={onChange}/>
      </Col>
    </Row>
  )
}

search.propTypes = {
  form: PropTypes.object.isRequired,
  onSearch: PropTypes.func,
  onAdd: PropTypes.func,
  field: PropTypes.string,
  keyword: PropTypes.string
}

export default Form.create()(search)
