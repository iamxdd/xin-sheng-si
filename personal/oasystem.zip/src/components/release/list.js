import React from 'react'
import {Table, Dropdown, Button, Menu, Icon, Modal,Tag,Tooltip,Badge} from 'antd'
import {TweenOneGroup} from 'rc-tween-one'
import styles from './list.less'
const confirm = Modal.confirm;

class list extends React.Component {
  constructor (props) {
    super(props);
    this.selectedRowKeys =[]
  }
  onEnd = (e) => {
    e.target.style.height = 'auto'
  };
  handleRefuse(){
    //下发数据
    const {dataSource}=this.props;
    //截取数据中的站点代码以及日期
    const item=dataSource[0]
    this.props.onRelaseData({type:0,stationCode:item.stationCode,timepoint:item.timepoint});
  }

  handleRelease(){
    //确认复核
    const {dataSource}=this.props;
    //截取数据中的站点代码以及日期
    const item=dataSource[0];
    this.props.onRelaseData({type:1,stationCode:item.stationCode,timepoint:item.timepoint});
  }
  renderColumns(key,text,record,origin) {
    const { causes } =record;
    
    if(text<0&&origin!=undefined){

      text=origin[key]
    }

    let cause=undefined
    let isValid=1
    //遍历causes,查找是否存在key
    for(var i=0;i<causes.length;i++){
      let item=causes[i];
      if(item["gas"]==key){
        cause=item["content"];
        isValid=item["isValid"]
        break
      }
    }
    return (
      cause==undefined?this.formatValue(text):
                 <Tooltip title={cause==""?'无说明':cause}>
                  <font style={{color: isValid==1?'blue':'red'}}>{this.formatValue(text)}</font>
                </Tooltip>
    )
  }
  formatValue(value){
    if(value<0){
      return '—'
    }
    return value
  }
  renderOperation(id,flag) {
      const {onRefuseItem,onRelaseItem} = this.props;

      if(flag==1){
          return(
            <span>
              <a onClick={() => onRefuseItem(id)}>下发</a>
            </span>
          )
      }else if(flag==2){
          return(
            <span>
              <a style={{color:'#999'}}>下发</a>
            </span>
          )
      }

  }
  render () {
    const {loading, dataSource, originSource,pagination, onPageChange,onRefuseItem,onRelaseItem,onRelaseData} = this.props;

    const columns = [
      {
        title: '站点',
        dataIndex: 'station',
        key: 'station',
        render: (text, record, index) => {
          if(text==null){
            return(<span></span>)
          }
          return text.name
        }
      },
      {
        title: '时间',
        dataIndex: 'timepoint',
        key: 'timepoint'
      }, {
        title: 'CO',
        dataIndex: 'co',
        key: 'co',
        render: (text, record, index) => this.renderColumns('co', text,record,originSource[index]),
      }, {
        title: 'NO2',
        dataIndex: 'no2',
        key: 'no2',
        render: (text, record, index) => this.renderColumns('no2', text,record,originSource[index]),
      }, {
        title: 'SO2',
        dataIndex: 'so2',
        key: 'so2',
        render: (text, record, index) => this.renderColumns('so2', text,record,originSource[index]),
      }, {
        title: 'O3',
        dataIndex: 'o3',
        key: 'o3',
        render: (text, record, index) => this.renderColumns('o3', text,record,originSource[index]),
      }, {
        title: 'PM10',
        dataIndex: 'pm10',
        key: 'pm10',
        render: (text, record, index) => this.renderColumns('pm10', text,record,originSource[index]),
      }, {
        title: 'PM25',
        dataIndex: 'pm25',
        key: 'pm25',
        render: (text, record, index) => this.renderColumns('pm25', text,record,originSource[index]),
      }, {
        title: '状态',
        dataIndex: 'flag',
        key: 'flag',
        render: (text, record, index) => {

          if(text==0||text==2){
            return <Badge status="default" text="待审核" />
          }else if(text==1){
            return <Badge status="error" text="待复核" />
          }else if(text==3){
            return <Badge status="success" text="已复核" />
          }
        },
      }
    ];
    const self = this;
    const button=function(){
      if(dataSource[0]==undefined||dataSource[0].flag==1){
        return(
          <div>
            <Button type="danger" onClick={()=>{self.handleRefuse()}}>下发数据</Button>
            <Button type="primary" onClick={()=>{self.handleRelease()}}>确认复核</Button>
          </div>
        )
      }
       return(<div></div>)
    }()
    return <div>
      <Table bordered  columns={columns} dataSource={dataSource} loading={loading} pagination={false} simple rowKey={record => record.id} />
      <div className={styles.tableOperations}>
          {button}
      </div>
    </div>
  }
}

export default list
