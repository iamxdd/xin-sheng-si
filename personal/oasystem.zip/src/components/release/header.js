import React, { PropTypes } from 'react'
import { Form, Button, Row, Col,DatePicker, Radio} from 'antd'
import moment from 'moment'
import SearchGroup from '../ui/search'
const RadioGroup = Radio.Group;
const dateFormatString = 'YYYY-MM-DD';
class header extends React.Component {
  constructor (props) {
    super(props);
    this.state={
      timepoint:props.timepoint==undefined?this.dateFormat(-1):props.timepoint,
    }
  }
  dateFormat(count){
    var dd = new Date();
    dd.setDate(dd.getDate()+count);//获取count天后的日期
    var y = dd.getFullYear();
    var m = dd.getMonth()+1;//获取当前月份的日期
    var d = dd.getDate();
    return y+"-"+m+"-"+d;
  }
  disabledDate(current) {
    // can not select days after today and today

    return current && current.valueOf() > Date.now();
  }
  onDateChange(date, dateString){
      this.setState({timepoint:dateString});
      this.props.onSearch({timepoint:dateString,stationCode:this.state.stationCode})
  }
  onStationChange(e){
      const stationCode=e.target.value;
      this.setState({stationCode:stationCode});
      this.props.onSearch({timepoint:this.state.timepoint,stationCode:stationCode})
  }
  shouldComponentUpdate(nextState,nextProps){
      return true
  }
  render(){
    const {stationCode,stations}=this.props;
    if(stations.data.length==0){
      return(<div></div>)
    }
    const defaultDate=this.state.timepoint;
    const defaultStation=stationCode==undefined?stations.data[0].code:stationCode;
    const nodes=this.props.stations.data.map(function(item){
        if(item.type==3){
          return (
            <Radio key={item.id} value={item.code}>{item.name}</Radio>
          )
        }
    });
    return (

      <Row gutter={24}>
        <Col lg={8} md={12} sm={16} xs={24} style={{marginBottom: 16}}>
          <DatePicker allowClear={false} disabledDate={this.disabledDate} defaultValue={moment(defaultDate, dateFormatString)} onChange={(date,dateString)=>{this.onDateChange(date,dateString)}}/>
        </Col>
        <Col lg={16} md={12} sm={8} xs={24} style={{marginBottom: 16, textAlign: 'right'}}>
          <RadioGroup onChange={(e)=>{this.onStationChange(e)}} value={defaultStation}>
            {nodes}
          </RadioGroup>
        </Col>
      </Row>
    )
  }
}



header.propTypes = {
  onSearch: PropTypes.func,
  onAdd: PropTypes.func,
  stations: PropTypes.object.isRequired,
  timepoint: PropTypes.string
};

export default header
