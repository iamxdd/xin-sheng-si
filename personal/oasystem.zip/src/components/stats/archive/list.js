import React from 'react'
import {Table, Dropdown, Button, Menu, Icon, Modal} from 'antd'
import {TweenOneGroup} from 'rc-tween-one'
import styles from './list.less'
const confirm = Modal.confirm;

class list extends React.Component {
  constructor (props) {
    super(props)
    this.te=null
  }
  format(v){
    
    if(v==undefined||v==null||v==Infinity||v==-Infinity||v==NaN||isNaN(v)){
      return '—'
    }

    return v.toFixed(2)+"%"
  }
  formatDay(v){
    
    if(v==undefined||v==null||v==Infinity||v==-Infinity||v==NaN||isNaN(v)){
      return '—'
    }
    return v
  }
  formatDensity(v){
    const {numbers} = this.props;
     if(v==undefined||v==null||v==Infinity||v==-Infinity||v==NaN||isNaN(v)||v<0){
      return '—'
    }
    return v
  }
  formatPercent(v){
    
     if(v==undefined||v==null||v==Infinity||v==-Infinity||v==NaN||isNaN(v)){
      return '—'
    }
    const {numbers} = this.props;
    return v.toFixed(numbers.no2==undefined?2:numbers.no2)+"%"
  }
  tableExport(){
    /* Excel Open XML spreadsheet (.xlsx) */
  
    let te=$("#table table").tableExport({formats:["xlsx","txt"]});
    return te
  }
  componentDidUpdate(){
    if(this.te!=null){
      this.te.reset()
    }else{
       this.te=this.tableExport()
    }
  }
  render () {

    const {loading, dataSource,dataSource1,dataType,numbers} = this.props;
    if(numbers.so2==undefined){
      numbers.so2=1
    }
    if(numbers.no2==undefined){
      numbers.no2=1
    }
    if(numbers.pm10==undefined){
      numbers.pm10=1
    }
    if(numbers.pm25==undefined){
      numbers.pm25=1
    }
    if(numbers.o3==undefined){
      numbers.o3=1
    }
    if(numbers.co==undefined){
      numbers.co=1
    }

    let arr = dataSource1.air_avg;
    
    if(dataType==2){
      arr=dataSource1.air_quality
    }

    let columns=[];
    if(dataType==2){
      columns = [
        {
          title: '站点/时间',
            dataIndex: 'name',
            key: 'name',
            render: (text, record, index) => {
              let timepoint=record.timepoint
              if(timepoint==null){
                return (
                  <span>内江市</span>
                )
              }
              let date=timepoint

             return (
                    <span>{date}</span>
                  )
            }
        }, {
          title: '优',
          children: [{
            title: '天数',
            dataIndex: '优',
            key: '优',
            sorter: (a, b) => a.优 - b.优,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
            
          },{
            title: '百分比',
            dataIndex: '优百分比',
            key: '优百分比',
            sorter: (a, b) => a.优百分比 - b.优百分比,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          }]
        }, {
          title: '良',
          children: [{
            title: '天数',
            dataIndex: '良',
            key: '良',
            sorter: (a, b) => a.良 - b.良,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
          },{
            title: '百分比',
            dataIndex: '良百分比',
            key: '良百分比',
            sorter: (a, b) => a.良百分比 - b.良百分比,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          }]
        }, {
          title: '轻度污染',
          children: [{
            title: '天数',
            dataIndex: '轻度污染',
            key: '轻度污染',
            sorter: (a, b) => a.轻度污染 - b.轻度污染,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
          },{
            title: '百分比',
            dataIndex: '轻度百分比',
            key: '轻度百分比',
            sorter: (a, b) => a.轻度百分比 - b.轻度百分比,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          }]
        }, {
          title: '中度污染',
          children: [{
            title: '天数',
            dataIndex: '中度污染',
            key: '中度污染',
            sorter: (a, b) => a.中度污染 - b.中度污染,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
          },{
            title: '百分比',
            dataIndex: '中度百分比',
            key: '中度百分比',
            sorter: (a, b) => a.中度百分比 - b.中度百分比,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          }]
        }, {
          title: '重度污染',
          children: [{
            title: '天数',
            dataIndex: '重度污染',
            key: '重度污染',
            sorter: (a, b) => a.重度污染 - b.重度污染,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
          },{
            title: '百分比',
            dataIndex: '重度百分比',
            key: '重度百分比',
            sorter: (a, b) => a.重度百分比 - b.重度百分比,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          }]
        }, {
          title: '严重污染',
          children: [{
            title: '天数',
            dataIndex: '严重污染',
            key: '严重污染',
            sorter: (a, b) => a.严重污染 - b.严重污染,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
          },{
            title: '百分比',
            dataIndex: '严重百分比',
            key: '严重百分比',
            sorter: (a, b) => a.严重百分比 - b.严重百分比,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          }]
        }, {
          title: '达标率',
          children: [{
            title: '百分比',
            dataIndex: '达标率',
            key: '达标率',
            sorter: (a, b) => a.达标率 - b.达标率,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          },{
            title: '同比变化率',
            dataIndex: '同比达标变率',
            key: '同比达标变率',
            sorter: (a, b) => a.同比达标变率 - b.同比达标变率,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          },{
            title: '环比变化率',
            dataIndex: '环比达标变率',
            key: '环比达标变率',
            sorter: (a, b) => a.环比达标变率 - b.环比达标变率,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          }]
        }, {
          title: '超标率',
          children: [{
            title: '百分比',
            dataIndex: '超标率',
            key: '超标率',
            sorter: (a, b) => a.超标率 - b.超标率,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          },{
            title: '同比变化率',
            dataIndex: '同比超标变率',
            key: '同比超标变率',
            sorter: (a, b) => a.同比超标变率 - b.同比超标变率,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          },{
            title: '环比变化率',
            dataIndex: '环比超标变率',
            key: '环比超标变率',
            sorter: (a, b) => a.环比超标变率 - b.环比超标变率,
            render: (text, record, index) => {
              return (<span>{this.format(text)}</span>)
            }
          }]
        }, {
          title: '重度及以上',
          children: [{
            title: '天数',
            dataIndex: '重度及以上',
            key: '重度及以上',
            sorter: (a, b) => a.重度及以上 - b.重度及以上,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
          },{
            title: '同比天数',
            dataIndex: '同比重度及以上',
            key: '同比重度及以上',
            sorter: (a, b) => a.同比重度及以上 - b.同比重度及以上,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
          },{
            title: '环比天数',
            dataIndex: '环比重度及以上',
            key: '环比重度及以上',
            sorter: (a, b) => a.环比重度及以上 - b.环比重度及以上,
            render: (text, record, index) => {
              return (<span>{this.formatDay(text)}</span>)
            }
          }]
        }
      ]
    }else{
      columns = [
        {
          title: '站点/时间',
            dataIndex: 'name',
            key: 'name',
            render: (text, record, index) => {
              let timepoint=record.timepoint
              if(timepoint==null){
                return (
                  <span>内江市</span>
                )
              }
              let date=timepoint
              if(timepoint.indexOf(" ")>0){
                  date=date.split(" ")[0]
                  return (
                    <span>{date}</span>
                  )
              }
              return (
                  <span>{date}</span>
                )
            }
        }, {
          title: 'SO2',
          children: [{
            title: '浓度',
            dataIndex: 'so2',
            key: 'so2',
            sorter: (a, b) => a.so2 - b.so2,
            render: (text, record, index) => {
              if(text<0){
                return '—'
              }
              return (<span>{text.toFixed(numbers.so2)}</span>)
            }
          },{
            title: '同比',
            dataIndex: 'same_so2',
            key: 'same_so2',
            sorter: (a, b) => a.same_so2 - b.same_so2,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          },{
            title: '环比',
            dataIndex: 'ring_so2',
            key: 'ring_so2',
            sorter: (a, b) => a.ring_so2 - b.ring_so2,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          }]
        }, {
          title: 'NO2',
          children: [{
            title: '浓度',
            dataIndex: 'no2',
            key: 'no2',
            sorter: (a, b) => a.no2 - b.no2,
            render: (text, record, index) => {
              if(text<0){
                return '—'
              }
              return (<span>{text}</span>)
            }
          },{
            title: '同比',
            dataIndex: 'same_no2',
            key: 'same_no2',
            sorter: (a, b) => a.same_no2 - b.same_no2,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          },{
            title: '环比',
            dataIndex: 'ring_no2',
            key: 'ring_no2',
            sorter: (a, b) => a.ring_no2 - b.ring_no2,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          }]
        }, {
          title: 'O3',
          children: [{
            title: '浓度',
            dataIndex: 'o3',
            key: 'o3',
            sorter: (a, b) => a.o3 - b.o3,
            render: (text, record, index) => {
              if(text<0){
                return '—'
              }
              return (<span>{text.toFixed(numbers.o3)}</span>)
            }
          },{
            title: '同比',
            dataIndex: 'same_o3',
            key: 'same_o3',
            sorter: (a, b) => a.same_o3 - b.same_o3,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          },{
            title: '环比',
            dataIndex: 'ring_o3',
            key: 'ring_o3',
            sorter: (a, b) => a.ring_o3 - b.ring_o3,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          }]
        }, {
          title: 'CO',
          children: [{
            title: '浓度',
            dataIndex: 'co',
            key: 'co',
            sorter: (a, b) => a.co - b.co,
             render: (text, record, index) => {
               if(text<0){
                return '—'
              }
              return (<span>{text}</span>)
            }
          },{
            title: '同比',
            dataIndex: 'same_co',
            key: 'same_co',
            sorter: (a, b) => a.same_co - b.same_co,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          },{
            title: '环比',
            dataIndex: 'ring_co',
            key: 'ring_co',
            sorter: (a, b) => a.ring_co - b.ring_co,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          }]
        }, {
          title: 'PM10',
          children: [{
            title: '浓度',
            dataIndex: 'pm10',
            key: 'pm10',
            sorter: (a, b) => a.pm10 - b.pm10,
             render: (text, record, index) => {
               if(text<0){
                return '—'
              }
              return (<span>{text}</span>)
            }
          },{
            title: '同比',
            dataIndex: 'same_pm10',
            key: 'same_pm10',
            sorter: (a, b) => a.same_pm10 - b.same_pm10,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          },{
            title: '环比',
            dataIndex: 'ring_pm10',
            key: 'ring_pm10',
            sorter: (a, b) => a.ring_pm10 - b.ring_pm10,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          }]
        }, {
          title: 'PM2.5',
          children: [{
            title: '浓度',
            dataIndex: 'pm25',
            key: 'pm25',
            sorter: (a, b) => a.pm25 - b.pm25,
             render: (text, record, index) => {
               if(text<0){
                return '—'
              }
              return (<span>{text}</span>)
            }
          },{
            title: '同比',
            dataIndex: 'same_pm25',
            key: 'same_pm25',
            sorter: (a, b) => a.same_pm25 - b.same_pm25,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          },{
            title: '环比',
            dataIndex: 'ring_pm25',
            key: 'ring_pm25',
            sorter: (a, b) => a.ring_pm25 - b.ring_pm25,
            render: (text, record, index) => {
              return (<span>{this.formatPercent(text)}</span>)
            }
          }]
        }
      ]
    }

    const self = this;
    return <div id="table">
      <Table bordered scroll={{ x: 1024, y: false }} columns={columns} dataSource={arr} loading={loading} pagination={false} simple rowKey={record => record.id} />
    </div>
  }
}

export default list
