import React, { PropTypes } from 'react'
import { Form, Button, Row, Col } from 'antd'
import ChartHour from './chart-hour'
import ChartDayTop from './chart-day-top'
import ChartDayBottom from './chart-day-bottom'
import ChartMonthTop from './chart-month-top'
import ChartMonthBottom from './chart-month-bottom'

const chart = ({
  dataSource,
  activeMenu,
  timestamp
}) => {
  if(activeMenu==undefined){
      activeMenu='hour'
  }

  if(activeMenu=='hour'){
      return <ChartHour activeMenu={activeMenu} dataSource={dataSource} />
  }
  if(activeMenu=='day'){
      return (<div>
            <ChartDayTop timestamp={timestamp} activeMenu={activeMenu} dataSource={dataSource}/>
            <ChartDayBottom timestamp={timestamp} activeMenu={activeMenu} dataSource={dataSource}/>
          </div>
      )
  }

  if(activeMenu=='month'||activeMenu=='quarter'||activeMenu=='halfyear'||activeMenu=='year'){
      return (<div>
            <ChartMonthTop timestamp={timestamp} activeMenu={activeMenu} dataSource={dataSource}/>
            <ChartMonthBottom timestamp={timestamp} activeMenu={activeMenu} dataSource={dataSource}/>
          </div>
      )
  }
};


export default chart
