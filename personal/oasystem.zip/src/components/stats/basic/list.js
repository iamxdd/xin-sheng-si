import React from 'react'
import {Table, Dropdown, Button, Menu, Icon, Modal,Badge} from 'antd'
import {TweenOneGroup} from 'rc-tween-one'
import {config,math} from '../../../utils'
import styles from './list.less'
const confirm = Modal.confirm;

class list extends React.Component {
  constructor (props) {

    super(props)
    this.te=null
  }
  tableExport(){
    /* Excel Open XML spreadsheet (.xlsx) */
  
    let te=$("#table table").tableExport({formats:["xlsx","txt"]});
    return te
  }
  parserGasValue(value){
    if(value==undefined||math(value)<=0){
      return '—'
    }
    return math(value)
  }
  componentDidUpdate(){
    if(this.te!=null){
      this.te.reset()
    }else{
       this.te=this.tableExport()
    }
  }
  componentDidMount(){
    window.requestAnimationFrame(function() {
       if(this.te==null){
        this.te=this.tableExport()
      }
    }.bind(this))
  }
  render () {
    const {loading, dataSource,type} = this.props;
    const qualityAirAll=dataSource.qualityAirAll

    let columns=[];
    if(type=='hour'||type=='day'){
        columns = [
          {
            title: '站点名称',
            dataIndex: 'stationName',
            key: 'stationName',
            render: (text, record, index) => {
              if(text==null){
                
                return(<span>内江市</span>)
              }
              return(<span>{text}</span>)
            }
          }, {
            title: '监测时间',
            dataIndex: 'timepoint',
            key: 'timepoint'
          }, {
            title: 'SO2',
            dataIndex: 'so2',
            key: 'so2',
            render: (text, record, index) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'NO2',
            dataIndex: 'no2',
            key: 'no2',
            render: (text, record, index) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'CO',
            dataIndex: 'co',
            key: 'co',
            render: (text, record, index) => {
              return(<span>{text==undefined||text<0?'—':text.toFixed(3)}</span>)
            }
          }, {
            title: 'O3',
            dataIndex: 'o3',
            key: 'o3',
            render: (text, record, index) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'PM2.5',
            dataIndex: 'pm25',
            key: 'pm25',
            render: (text, record, index) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'PM10',
            dataIndex: 'pm10',
            key: 'pm10',
            render: (text, record, index) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'AQI空气质量指数',
            dataIndex: 'aqi',
            key: 'aqi',
            render: (text, record, index) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: '首要污染物',
            dataIndex: 'primaryPollutant',
            key: 'primaryPollutant',
            render: (text, record, index) => {
              
              if(text=="—"||text=="-"||text==""||parseInt(record.aqi)<=50){
                return(<span>—</span>);
              }
              if(text!=undefined){
                
                const array=text.split(",");
                let str=""
                for(var i=0;i<array.length;i++){
                  str+=","+(config.gas[array[i]]==undefined?text:config.gas[array[i]])
                }
                if(str!=""){
                    str=str.substring(1)
                }
                if(str==""||str==undefined){
                  str="-"
                }
                return(<span>{str}</span>);
              }
              const array=[record.ico,record.iso2,record.ino2,record.ipm10,record.ipm25,record.io3]
              const name=["一氧化碳(CO)","二氧化硫(SO2)","二氧化氮(NO2)","细颗粒物(PM10)","颗粒物(PM2.5)","臭氧(O3)"]
              const max=Math.max.apply(null, array)

              let str=""
              for(var i=0;i<array.length;i++){
                if(max==array[i]){
                  str+=","+name[i]
                }
              }
              if(str!=""){
                  str=str.substring(1)
              }
              if(max<=0){
                str='—'
              }
              return(<span>{str}</span>);
             
            }
          }, {
            title: '空气质量级别',
            dataIndex: 'aqi',
            key: 'level',
            render: (text, record) => {
                text=math(text)
                if(text=='—'){
                  return(<span>{text}</span>)
                }
                else if(text<=50){
                  return <Badge status="default" text="一级" />
                }else if(51<=text&&text<=100){
                  return <Badge status="success" text="二级" />
                }else if(101<=text&&text<=150){
                  return <Badge status="error" text="三级" />
                }else if(151<=text&&text<=200){
                  return <Badge status="error" text="四级" />
                }else if(201<=text&&text<=300){
                  return <Badge status="error" text="五级" />
                }else if (text>301){
                  return <Badge status="error" text="六级" />
                }
            }
          }, {
            title: '空气质量状态',
            dataIndex: 'aqi',
            key: 'cate',
            render: (text, record) => {
                text=math(text)
                if(text=='—'){
                  return(<span>{text}</span>)
                }
                else if(text<=50){
                  return <Badge status="default" text="优" />
                }else if(51<=text&&text<=100){
                  return <Badge status="success" text="良" />
                }else if(101<=text&&text<=150){
                  return <Badge status="error" text="轻度污染" />
                }else if(151<=text&&text<=200){
                  return <Badge status="error" text="中度污染" />
                }else if(201<=text&&text<=300){
                  return <Badge status="error" text="重度污染" />
                }else if (text>301){
                  return <Badge status="error" text="严重污染" />
                }
            }
          }
        ]
    }
    if(type=='month'||type=='quarter'||type=='halfyear'||type=='year'){
        columns = [
          {
            title: '站点名称',
            dataIndex: 'stationName',
            key: 'stationName',
            render: (text, record, index) => {
              if(text==null){
                
                return(<span>内江市</span>)
              }
              return(<span>{text}</span>)
            }
          }, {
            title: '监测时间',
            dataIndex: 'd',
            key: 'd',
            render: (text, record, index) => {
  
              let xaxi=""
              const str=text.split("-")
              if(text.indexOf("年")>=0){
                  xaxi=text
              }else if(type=="month"){
                  xaxi=str[0]+"年"+str[1]+"月"
              }else if(type=="quarter"){
                  xaxi=str[0]+"年"+str[1]+"季度"
              }else if(type=="halfyear"){
                  xaxi=str[0]+"年"
                  if(str[1]==1){
                      xaxi+="上半年"
                  }else{
                      xaxi+="下半年"
                  }
              }else if(type=="year"){
                  xaxi=str[0]+"年"
              }else{
                  xaxi=text
              }
              return(<span>{xaxi}</span>)
            }
          }, {
            title: 'SO2',
            dataIndex: 'avgSo2',
            key: 'so2',
            render: (text, record) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'NO2',
            dataIndex: 'avgNo2',
            key: 'no2',
            render: (text, record) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'CO',
            dataIndex: 'avgCo',
            key: 'co',
            render: (text, record) => {
              return(<span>{text==undefined||text<0?'-':text.toFixed(3)}</span>)
            }
          }, {
            title: 'O3',
            dataIndex: 'avgO3',
            key: 'o3',
            render: (text, record) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'PM2.5',
            dataIndex: 'avgPm25',
            key: 'pm25',
            render: (text, record) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: 'PM10',
            dataIndex: 'avgPm10',
            key: 'pm10',
            render: (text, record) => {
              return(<span>{this.parserGasValue(text)}</span>)
            }
          }, {
            title: '重污染天数',
            dataIndex: 'z',
            key: 'z',
            render: (text, record,index) => {
              return(<span>{qualityAirAll.重度[index]+qualityAirAll.严重[index]}</span>)
            }
          }, {
            title: '优',
            dataIndex: 'y',
            key: 'y',
            render: (text, record,index) => {
              return(<span>{qualityAirAll.优[index]}</span>)
            }
          }, {
            title: '良',
            dataIndex: 'l',
            key: 'l',
            render: (text, record,index) => {
              return(<span>{qualityAirAll.良[index]}</span>)
            }
          }, {
            title: '轻度污染',
            dataIndex: 'q',
            key: 'q',
            render: (text, record,index) => {
              return(<span>{qualityAirAll.轻度[index]}</span>)
            }
          }, {
            title: '中度污染',
            dataIndex: 'zd',
            key: 'zd',
            render: (text, record,index) => {
              return(<span>{qualityAirAll.中[index]}</span>)
            }
          }, {
            title: '重度污染',
            dataIndex: 'zdw',
            key: 'zdw',
            render: (text, record,index) => {
              return(<span>{qualityAirAll.重度[index]}</span>)
            }
          }, {
            title: '严重污染',
            dataIndex: 'yz',
            key: 'yz',
            render: (text, record,index) => {
              return(<span>{qualityAirAll.严重[index]}</span>)
            }
          }
        ]
    }

    const self = this;

    return <div id="table">
                <Table bordered columns={columns} dataSource={dataSource.list} loading={loading}  pagination={false} simple rowKey={record => record.id} />
           </div>
  }
}

export default list
