import React, { PropTypes } from 'react'
import { routerRedux } from 'dva/router'
import { connect } from 'dva'
import { Spin } from 'antd'
import ReviewList from '../components/review/editlist'
import ReviewHeader from '../components/review/header'
import Chart from '../components/review/chart'
/**
 * 数据审核
 */
function Review ({ location, dispatch, app,review }) {
  const {login}=app;
  const {loading,copyList,list,origin, pagination, timestamp,currentItem, modalVisible, modalType } = review;
  const { field, keyword,timepoint } = location.query;

  const reviewModalProps = {
    item: modalType === 'create' ? {} : currentItem,
    type: modalType,
    visible: modalVisible,
    onOk (data) {
      dispatch({
        type: `review/${modalType}`,
        payload: data
      })
    },
    onCancel () {
      dispatch({
        type: 'review/hideModal'
      })
    }
  };

  const reviewListProps = {
    copyList:copyList,
    dataSource: list,
    originSource: origin,
    loading,
    pagination: pagination,
    onPageChange (page) {

      const { query, pathname } = location;
      dispatch(routerRedux.push({
        pathname: pathname,
        query: {
          ...query,
          page: page.current,
          pageSize: page.pageSize
        }
      }))
    },
    onEditItemDone (index, type,item) {
      let actionType="update";
      if(type=="cancel"){
          actionType="editDone"
      }
      
      dispatch({
        type: `review/${actionType}`,
        payload: {
          data: list,
          index: index,
          status:type,
          item:item,
          ...location.query
        }
      })
    },
    onEditItem (index) {

      dispatch({
        type: 'review/onEdit',
        payload: {
          data: list,
          index: index
        }
      })
    },
    onCommitItem(id){
      dispatch({
        type: 'review/commit',
        payload: {
          ...location.query
        }
      })
    }
  };

  const reviewSearchProps = {
    field,
    timepoint,
    onSearch (fieldsValue) {
      fieldsValue.timepoint.length ? dispatch(routerRedux.push({
        pathname: '/review/list',
        query: {
          timepoint: fieldsValue.timepoint
        }
      })) : dispatch(routerRedux.push({
        pathname: '/review/list'
      }))
    }
  };
  const chartProps={
     dataSource: list,
     timestamp
  };
  return (
    <div className='content-inner'>
      <Spin tip='loading...' spinning={loading} size='large'>
      <ReviewHeader {...reviewSearchProps} />
      <Chart {...chartProps}/>
      <ReviewList {...reviewListProps} />
      </Spin>
    </div>
  )
}

Review.propTypes = {
  review: PropTypes.object,
  location: PropTypes.object,
  dispatch: PropTypes.func
};

function mapStateToProps ({ app,review }) {
  return { app,review }
}

export default connect(mapStateToProps)(Review)
