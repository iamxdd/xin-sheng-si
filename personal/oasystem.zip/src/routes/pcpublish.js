/**
 * Created by Administrator on 2017/2/28 0028.
 */
import React, { PropTypes } from 'react'
import { routerRedux } from 'dva/router'
import { connect } from 'dva'
import { Spin } from 'antd'
import Pcpublishlish from '../components/publishdata/list';
import Pcpublishday from '../components/publishdata/listday';

/**
 * 站点信息列表
 */
function Pcpublish ({ location, dispatch, app,pcpublish }) {
  const {login}=app;
  const {loading,list, pagination,daylist, currentItem, modalVisible, modalType } = pcpublish;
  const { field, keyword } = location.query;

  const pcpublishModalProps = {
    item: modalType === 'create' ? {} : currentItem,
    type: modalType,
    visible: modalVisible,
    onOk (data) {
      dispatch({
        type: `pcpublish/${modalType}`,
        payload: data
      })
    },
    onCancel () {
      dispatch({
        type: 'pcpublish/hideModal'
      })
    }
  };

  const pcpublishListProps = {
    dataSource: list,
    dataSorce2:daylist,
    loading,
    pagination: pagination,
    onPageChange (page) {

      const { query, pathname } = location;
      dispatch(routerRedux.push({
        pathname: pathname,
        query: {
          ...query,
          page: page.current,
          pageSize: page.pageSize
        }
      }))
    }
  };
  return (
    <div className='content-inner'>
      <Spin tip='loading...' spinning={loading} size='large'>
      <Pcpublishlish {...pcpublishListProps} />
      <br/><br/>
      <Pcpublishday  {...pcpublishListProps} />
      </Spin>
    </div>
  )
}

Pcpublish.propTypes = {
  pcpublish: PropTypes.object,
  location: PropTypes.object,
  dispatch: PropTypes.func
};

function mapStateToProps ({ app,pcpublish }) {
  return { app,pcpublish }
}

export default connect(mapStateToProps)(Pcpublish)
