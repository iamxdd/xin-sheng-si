/**
 * Created by Administrator on 2017/2/28 0028.
 */
import React, {PropTypes} from 'react'
import Publishdatalist from '../components/publishdata/publishdatalist';
import {connect} from 'dva'

function Publishdata ({publishdata, dispatch}) {
  return(
    <div>数据发布页面</div>
  )
}

export default connect()(Publishdata)
