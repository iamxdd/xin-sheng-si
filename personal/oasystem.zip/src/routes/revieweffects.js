import React, { PropTypes } from 'react'
import { routerRedux } from 'dva/router'
import { connect } from 'dva'
import { Spin } from 'antd'
import Revieweffects from '../components/review/revieweffects'

/**
 * 站点信息列表
 */
function Revieweffect ({ location, dispatch, app,revieweffects }) {
  const {login}=app;
  const {loading,list, pagination, currentItem, modalVisible, modalType } = revieweffects;
  const { startTime, endTime } = location.query;

  
  const revieweffectsListProps = {
    dataSource: list,
    loading,
    startTime,
    endTime,
    pagination: pagination,
    onPageChange (page) {

      const { query, pathname } = location;
      dispatch(routerRedux.push({
        pathname: pathname,
        query: {
          ...query,
          page: page.current,
          pageSize: page.pageSize
        }
      }))
    },
    onDateChange(time){
      const { query, pathname } = location;
      dispatch(routerRedux.push({
        pathname: pathname,
        query: {
          ...query,
          startTime : time[0],
          endTime: time[1],
        }
      }))
    },
    onDeleteItem (id) {
      dispatch({
        type: 'revieweffects/delete',
        payload: id
      })
    },
    onEditItem (item) {
      dispatch({
        type: 'revieweffects/showModal',
        payload: {
          modalType: 'update',
          currentItem: item
        }
      })
    }
  };


  return (
    <div className='content-inner'>
      <Spin tip='loading...' spinning={loading} size='large'>
      <Revieweffects {...revieweffectsListProps} />
      </Spin>
    </div>
  )
}

Revieweffect.propTypes = {
  station: PropTypes.object,
  location: PropTypes.object,
  dispatch: PropTypes.func
};

function mapStateToProps ({ app,revieweffects }) {
  return { app,revieweffects }
}

export default connect(mapStateToProps)(Revieweffect)
