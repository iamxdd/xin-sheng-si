import React, { PropTypes } from 'react'
import { routerRedux } from 'dva/router'
import { connect } from 'dva'
import { Spin } from 'antd'
import RoleList from '../components/role/list'
import RoleSearch from '../components/role/search'
import RoleModal from '../components/role/modal'

/**
 * 角色信息列表
 */
function Role ({ location, dispatch, app,role }) {
  const {login}=app
  const {loading,list, pagination, currentItem, modalVisible, modalType,permissions } = role
  const { field, keyword } = location.query

  const roleModalProps = {
    item: modalType === 'create' ? {} : currentItem,
    type: modalType,
    permissions:permissions,
    visible: modalVisible,
    onOk (data) {
      dispatch({
        type: `role/${modalType}`,
        payload: data
      })
    },
    onCancel () {
      dispatch({
        type: 'role/hideModal'
      })
    }
  }

  const roleListProps = {
    dataSource: list,
    loading,
    pagination: pagination,
    onPageChange (page) {
      
      const { query, pathname } = location
      dispatch(routerRedux.push({
        pathname: pathname,
        query: {
          ...query,
          page: page.current,
          pageSize: page.pageSize
        }
      }))
    },
    onDeleteItem (id) {
      dispatch({
        type: 'role/delete',
        payload: id
      })
    },
    onEditItem (item) {
      console.log(item)
      dispatch({
        type: 'role/edit',
        payload: {
          modalType: 'update',
          currentItem: item
        }
      })
    }
  }

  const roleSearchProps = {
    field,
    keyword,
    onSearch (fieldsValue) {
      fieldsValue.keyword.length ? dispatch(routerRedux.push({
        pathname: '/system/role',
        query: {
          field: fieldsValue.field,
          keyword: fieldsValue.keyword
        }
      })) : dispatch(routerRedux.push({
        pathname: '/system/role'
      }))
    },
    onAdd () {
      dispatch({
        type: 'role/add',
        payload: {
          modalType: 'create'
        }
      })
    }
  }

  const RoleModalGen = () =>
    <RoleModal {...roleModalProps} />

  return (
    <div className='content-inner'>
      <Spin tip='loading...' spinning={loading} size='large'>
      <RoleSearch {...roleSearchProps} />
      <RoleList {...roleListProps} />
      <RoleModalGen />
      </Spin>
    </div>
  )
}

Role.propTypes = {
  role: PropTypes.object,
  location: PropTypes.object,
  dispatch: PropTypes.func
}

function mapStateToProps ({ app,role }) {
  return { app,role }
}

export default connect(mapStateToProps)(Role)
