
import React, {PropTypes} from 'react'
import {connect} from 'dva'

function Dashboard ({dashboard, dispatch}) {
    return(
        <div>
           <h1>成都市府南河信息综合管理平台</h1>
            {/*<iframe style={{width:'100%',height:"900px",border:0}} src="http://182.135.64.132:100/publish/"></iframe>*/}
        </div>
    )
}

export default connect()(Dashboard)