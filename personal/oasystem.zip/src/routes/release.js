import React, { PropTypes } from 'react'

import { routerRedux } from 'dva/router'
import { connect } from 'dva'
import { Spin } from 'antd'
import ReleaseList from '../components/release/list'
import ReleaseHeader from '../components/release/header'
import Chart from '../components/release/chart'
/**
 * 数据下发
 */
function Release ({ location, dispatch, app,release }) {
  const {login}=app;
  const {loading,list,origin,stations, currentItem } = release;
  let { stationCode, timepoint } = location.query;

  const releaseListProps = {
    dataSource: list,
    originSource: origin,
    loading,
    onRelaseData(data){
      if(timepoint==undefined){
        const timestamp = Date.parse(new Date())
        //24小时前
        const n=timestamp-60*60*24*1000
        timepoint=new Date(n).format("yyyy-MM-dd HH:mm:ss")
      }
      data.timepoint=timepoint
      dispatch({
        type: 'release/updateAllflog',
        payload: data
      })
    }

  };

  const releaseSearchProps = {
    stationCode,
    timepoint,
    stations,
    onSearch (fieldsValue) {
      dispatch(routerRedux.push({
         pathname: '/review/release',
         query:{
           ...fieldsValue
         }
      }))
    },
    onAdd () {
      dispatch({
        type: 'review/showModal',
        payload: {
          modalType: 'create'
        }
      })
    },
  };

  const chartProps={
     dataSource: list
  };

  return (
    <div className='content-inner'>
      <Spin tip='loading...' spinning={loading} size='large'>
      <ReleaseHeader {...releaseSearchProps} />
      <Chart {...chartProps}/>
      <ReleaseList {...releaseListProps} />
      </Spin>
    </div>
  )
}

Release.propTypes = {
  release: PropTypes.object,
  location: PropTypes.object,
  dispatch: PropTypes.func
};

function mapStateToProps ({ app,release }) {
  return { app,release }
}

export default connect(mapStateToProps)(Release)
