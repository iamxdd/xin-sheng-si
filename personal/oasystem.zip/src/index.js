import dva from 'dva';
import {message} from 'antd';
import './index.html';

// 1. Initialize
const app = dva({
  onError(e) {
console.log(e)
     if(!e.message){
         return;
     }
     
     if(app._models[2]!=undefined){
        const m=app._models[2].namespace
        
        app._store.dispatch({type: m+'/hideLoading'})
     }
     
     app._store.dispatch({type: 'app/errmsg',payload: e.message})
  },
});

// 2. Plugins
// app.use({});

// 3. Model
app.model(require('./models/app'))

// 4. Router
app.router(require('./router'));

// 5. Start
app.start('#root');
